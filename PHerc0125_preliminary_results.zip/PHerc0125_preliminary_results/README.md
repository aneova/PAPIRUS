# PHerc0125 — preliminary candidate dossier

Prepared for Anna Korotkova, 4 November 2026.

This package records ten user-selected candidate positions. Letter identifications are tentative and have not been validated by papyrologists. The numbers identify the order of receipt, not a word or line. No continuous transcription is claimed.

## Data and method
Scroll: PHerc0125. Scan: 20250821151825-9.362um-1.2m-113keV-masked, L0, 9.362 µm voxels. Surface: auto_grown_20261020191217595. Inspection in Papyrus Analyzer; latest observed version 0.11.7. Candidate positions are in the active surface U/V grid. D is displacement along the rendered surface normal relative to its reference surface, not a global CT slice number. Normal orientation and the U/V-to-XYZ mapping must be supplied with the actual mesh.

Candidates 1–2 were reported in adjacent-depth difference mode; 3–10 in original CT mode, following the user's final correction. The available Analyzer code computes difference[D] = CT[D] − CT[D−1] at these non-boundary depths; reproduce against the exact code and CT export used. Thus candidate 1 at D=-1 compares -1 with -2, and candidate 2 at D=0 compares 0 with -1. Display levels and exact viewing rotations were not supplied for each image.

Candidates were selected manually. The included images are not model predictions. Earlier pretrained-model experiments on PHerc0125 did not establish these candidates as ink and are not evidence of their validity. No training on these candidate annotations is claimed.

## Evidence limits
The package contains supplied PNG crops/screenshots, not numerical CT arrays or surface geometry. A dark mark may be ink, fibre structure, a crack or another imaging feature. Difference rendering emphasizes changes with depth and does not specifically isolate ink. Original renders and depth-series checks are still required. Some screenshots contain a cyan ring, grid lines or UI; these are reference material, not the final clean submission image. Standalone crops have no independently recoverable physical scale. The pixel sizes in candidates.json describe whole supplied images, not letter dimensions.

## What must be added for a full submission
- Verify all ten proposed candidates, including the new Phi: its centre and visible strokes have not been localized. Ten catalogue entries do not establish ten legible characters.
- A shared image demonstrating at least ten independently legible characters within one 4 cm² surface region. The new Phi has not been shown to belong to the same region as candidates 1–9.
- Confirmed U/V and marked position for new Phi (candidate 10), plus confirmed centres for Gamma, Epsilon and Pi; their currently recorded numbers are cursor readings. Confirm exact centres for all candidates from saved annotations/export.
- The corresponding tifxyz mesh (x.tif, y.tif, z.tif, meta.json), including the flattening and grid origin/offset metadata. These files are not included here.
- Numerical CT export of the common ROI, including reference surface, depth offsets, sampling, U/V mapping and intensity values; original CT and neighboring depths for comparison.
- One clean programmatically generated common image traceable to the submitted mesh, a 1 cm scale bar, and pixel/mm measurements of representative letters. Preserve an unannotated copy; show row positions separately without drawing over characters.
- Exact reproducible source code, dependencies, input locations, operating instructions and a short demonstration video for the interactive workflow. Include validation on public known-text data and discuss false positives.

## Official requirements consulted
https://scrollprize.org/prizes#first-letters-prizes (accessed 4 November 2026).
The published page lists PHerc0125 as eligible and requires at least ten legible letters in a single 4 cm² region, corresponding tifxyz geometry, a programmatically generated static image, scale and representative letter sizes, methodology and validation. This archive is preliminary and does not establish compliance. Follow the current official submission route on that page. Keep findings non-public pending the organizers' process.

## Package
Open report.html in a browser for the visual catalogue. candidates.json preserves metadata and image checksums. images/ contains unchanged copies of the supplied PNGs. email_draft.txt is an unsent English request for preliminary assessment.
